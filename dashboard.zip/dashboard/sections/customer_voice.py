import streamlit as st

from components.ui.section import section_title


def render(pain_df, love_df):

    section_title(
        "🎙 Customer Voice",
        "What customers appreciate most and where they experience the biggest issues."
    )

    pain_top = pain_df.head(5).reset_index(drop=True)
    love_top = love_df.head(5).reset_index(drop=True)

    left, right = st.columns(2)

    with left:
        with st.container(border=True):

            st.markdown("### ⚠ Main Customer Concerns")
            st.caption("Based on estimated negative review mentions")

            max_pain = max(
                float(pain_df["estimated_negative_reviews"].max()),
                1,
            )

            for idx, row in pain_top.iterrows():

                st.markdown(
                    f"**{row['issue']}**"
                )

                st.progress(
                    float(row["estimated_negative_reviews"]) / max_pain,
                    text="",
                )

                st.caption(
                    f"{int(row['estimated_negative_reviews'])} mentions | "
                    f"{row['phones_affected']} phones"
                )

                if idx < len(pain_top) - 1:
                    st.divider()

    with right:

        with st.container(border=True):

            st.markdown("### 💚 Most Appreciated Features")
            st.caption("Based on estimated positive review mentions")

            max_love = max(
                float(love_df["estimated_positive_reviews"].max()),
                1,
            )

            for idx, row in love_top.iterrows():

                st.markdown(
                    f"**{row['feature']}**"
                )

                st.progress(
                    float(row["estimated_positive_reviews"]) / max_love,
                    text="",
                )

                st.caption(
                    f"{int(row['estimated_positive_reviews'])} mentions | "
                    f"{row['phones_affected']} phones"
                )

                if idx < len(love_top) - 1:
                    st.divider()

    st.divider()
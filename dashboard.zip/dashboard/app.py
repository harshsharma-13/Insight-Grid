import streamlit as st

from config import APP_TITLE, DEFAULT_PAGE_ICON
from dashboard_data import get_kpis, get_featured_phones
from ai_search import answer_search_query
from market_intelligence import (
    get_market_dataset,
    aggregate_pain_points,
    aggregate_customer_loves,
    get_segment_overview,
    get_brand_landscape,
    build_market_summary,
)
from components.style_loader import load_css
from components.ui.search import ai_search_box
from components.ui.section import section_title
from components.ui.phone_tile import phone_tile
from components.ui.summary_tiles import summary_tile
from sections.hero import render as hero
from sections.market_health import render as market_health
from sections.executive_summary import render as executive_summary
from sections.customer_voice import render as customer_voice


st.set_page_config(
    page_title=APP_TITLE,
    page_icon=DEFAULT_PAGE_ICON,
    layout="wide",
)

load_css()

# ============================
# Load datasets
# ============================

kpis = get_kpis()
market_df = get_market_dataset()

hero()

query = ai_search_box()

if query:

    st.markdown("## 🤖 AI Search Results")
    st.caption(f"Query: {query}")

    with st.spinner("Searching specifications, review sentiment and AI insights..."):
        answer, candidates = answer_search_query(query)

    with st.container(border=True):
        st.markdown(answer)

    if not candidates.empty:
        st.markdown("### Recommended Phones")

        for i in range(0, len(candidates), 4):
            cols = st.columns(4)
            batch = candidates.iloc[i:i + 4]

            for col, (_, phone) in zip(cols, batch.iterrows()):
                with col:
                    phone_tile(phone, key_prefix=f"search_{i}")


market_health(
    kpis,
    market_df,
)

summary = build_market_summary(market_df)

executive_summary(summary)

filter_col1, filter_col2 = st.columns(2)

brands = ["All"] + sorted([b for b in market_df["brand"].dropna().unique().tolist() if b])
segment_labels = {
    "All": "All",
    "Budget": "Budget (≤ ₹15,000)",
    "Mid-range": "Mid-range (₹15,001–₹25,000)",
    "Upper Mid-range": "Upper Mid-range (> ₹25,000)",
}

segments = list(segment_labels.keys())

with filter_col1:
    selected_brand = st.selectbox("Filter by Brand", brands)

with filter_col2:
    selected_segment_label = st.selectbox(
    "Filter by Segment",
    [segment_labels[s] for s in segments],
)

selected_segment = {
    label: key for key, label in segment_labels.items()
}[selected_segment_label]

pain_df = aggregate_pain_points(
    market_df,
    brand=selected_brand,
    segment=selected_segment,
)

love_df = aggregate_customer_loves(
    market_df,
    brand=selected_brand,
    segment=selected_segment,
)

top_pain = pain_df.iloc[0]
top_love = love_df.iloc[0]

s1, s2, s3, s4 = st.columns(4)

with s1:
    summary_tile(
        "Top Customer Concern",
        top_pain["issue"],
        f"{top_pain['phones_affected']} phones affected",
        "⚠️",
        "#EF4444",
    )

with s2:
    summary_tile(
        "Estimated Negative Mentions",
        int(top_pain["estimated_negative_reviews"]),
        f"Severity: {top_pain['severity']}",
        "📉",
        "#F97316",
    )

with s3:
    summary_tile(
        "Most Loved Feature",
        top_love["feature"],
        f"{top_love['phones_affected']} phones affected",
        "💚",
        "#22C55E",
    )

with s4:
    summary_tile(
        "Estimated Positive Mentions",
        int(top_love["estimated_positive_reviews"]),
        f"Avg positive: {top_love['avg_positive_percent']}%",
        "📈",
        "#3B82F6",
    )

customer_voice(
    pain_df,
    love_df,
)

section_title(
    "🧭 Segment Overview",
    "Compare market health across price bands and identify each segment’s main strength, concern and leading brand."
)

SEGMENT_DISPLAY = {
    "Budget": "Budget (≤ ₹15,000)",
    "Mid-range": "Mid-range (₹15,001–₹25,000)",
    "Upper Mid-range": "Upper Mid-range (> ₹25,000)",
}

segment_df = get_segment_overview(market_df)

seg_cols = st.columns(len(segment_df)) if not segment_df.empty else []

for col, (_, row) in zip(seg_cols, segment_df.iterrows()):
    segment_title = SEGMENT_DISPLAY.get(row["segment"], row["segment"])

    with col:
        with st.container(border=True):
            st.markdown(f"### {segment_title}")
            st.markdown(f"## {row['avg_positive']}%")
            st.caption("Average Positive Sentiment")
            st.divider()
            st.markdown(f"📱 **Phones:** {row['phones']}")
            st.markdown(f"👍 **Top Strength:** {row['top_strength']}")
            st.markdown(f"⚠️ **Top Concern:** {row['top_concern']}")
            st.markdown(f"🏆 **Leading Brand:** {row['leading_brand']}")

st.divider()

section_title(
    "🏆 Competitive Landscape",
    "Brand-level health, strengths and weaknesses."
)

brand_df = get_brand_landscape(market_df)

best_brand = brand_df.iloc[0]
most_reviews = brand_df.sort_values("reviews", ascending=False).iloc[0]
biggest_concern = brand_df.sort_values("avg_negative", ascending=False).iloc[0]

b1, b2, b3 = st.columns(3)

with b1:
    summary_tile(
        "Strongest Brand",
        best_brand["brand"],
        f"{best_brand['avg_positive']}% avg positive sentiment",
        "🏆",
        "#22C55E",
    )

with b2:
    summary_tile(
        "Highest Review Coverage",
        most_reviews["brand"],
        f"{int(most_reviews['reviews'])} reviews analysed",
        "💬",
        "#3B82F6",
    )

with b3:
    summary_tile(
        "Biggest Brand Concern",
        biggest_concern["brand"],
        f"{biggest_concern['top_concern']} is the top concern",
        "⚠️",
        "#F97316",
    )

st.markdown("### Brand Sentiment Leaderboard")

leader_cols = st.columns(4)

for index, (_, row) in enumerate(brand_df.head(4).iterrows()):
    with leader_cols[index]:
        with st.container(border=True):
            st.markdown(f"### 🏆 {row['brand']}")
            st.markdown(f"## {row['avg_positive']}%")
            st.caption("Average positive sentiment")
            st.markdown(f"👍 **Strength:** {row['top_strength']}")
            st.markdown(f"⚠️ **Concern:** {row['top_concern']}")

st.markdown("### Brand Performance Ranking")

for _, row in brand_df.head(10).iterrows():
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns([2, 1, 2, 2])

        with c1:
            st.markdown(f"**{row['brand']}**")

        with c2:
            st.markdown(f"**{row['avg_positive']}%**")

        with c3:
            st.caption(f"Strength: {row['top_strength']}")

        with c4:
            st.caption(f"Concern: {row['top_concern']}")

st.markdown("### Brand Health Cards")

top_brands = brand_df.head(6)
brand_cols = st.columns(3)

for index, (_, row) in enumerate(top_brands.iterrows()):
    with brand_cols[index % 3]:
        with st.container(border=True):
            st.markdown(f"### {row['brand']}")
            st.markdown(f"## {row['avg_positive']}%")
            st.caption("Average positive sentiment")
            st.markdown("---")
            st.markdown(f"👍 **Strength:** {row['top_strength']}")
            st.markdown(f"⚠️ **Concern:** {row['top_concern']}")
            st.markdown(f"📱 **Phones:** {row['phones']}")
            st.markdown(f"💬 **Reviews:** {int(row['reviews'])}")

st.divider()

section_title(
    "🔥 Featured Smartphones",
    "Top phones ranked by positive consumer sentiment."
)

featured = get_featured_phones(4)
cols = st.columns(4)

for col, (_, phone) in zip(cols, featured.iterrows()):
    with col:
        phone_tile(phone, key_prefix="featured")